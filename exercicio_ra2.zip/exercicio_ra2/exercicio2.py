media = float(input("Insira sua média: "))
if media >= 7:
    print("Sua média é " + str(media) + " e você está aprovado!")
else: print("Sua média é " + str(media) + " e você está reprovado!")