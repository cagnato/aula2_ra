idade = int(input("Insira sua idade: "))
if idade >= 18:
    print ("Você tem " + str(idade) + " anos e pode fazer uma habilitação")
else: print ("Você tem " + str(idade) + " anos e não pode fazer uma habilitação")
