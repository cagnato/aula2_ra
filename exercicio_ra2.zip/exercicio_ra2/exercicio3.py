pdl = int(input("Insira seus PdL: "))

if pdl <= 999: 
    print("TU É FERRO!??? KKKKKKKKKKKKKKKK") 
elif pdl >= 1000 and pdl <= 1999: 
    print("Bronze paizão??? Melhore pô") 
elif pdl >= 2000 and pdl <= 2999: 
    print("Pratinha véi pôdi") 
elif pdl >= 3000 and pdl <= 3999: 
    print("Gold falido") 
elif pdl >= 4000 and pdl <= 4999: 
    print("Aspirante a high elo (plat)") 
elif pdl >= 5000 and pdl <= 5999: 
    print("Diminha chei d ego") 
elif pdl >= 6000 and pdl <= 6999: 
    print("Mestre? ta bem até")
elif pdl >= 7000 and pdl <= 7999: 
    print("Grão-mestre? Slk, n tem vida")
else: 
    print("Desafiante? Tu já tocou em grama??")