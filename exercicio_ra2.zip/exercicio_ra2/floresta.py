print("Voce entrou na floresta, porém se deparou com uma bifurcação, deseja seguir pela esquerda ou direita?")

caminho = input("Insira seu caminho: ")

S = str
N = str

if caminho == "esquerda":
    print("Voce encontrou um rio, deseja atravessa-lo? S/N")
    resposta = input("Escolha sua ação: ")
    if resposta == S:
        print("Voce foi atravessar o rio, mas caiu nele e se molhou! Voce não é atlético, amigo 🤦‍♂️")
    else:
        print("Voce não tentou atravessar o rio e continuou seco! Bom trabalho.👍")
elif caminho == "direita":
    print("Voce encontrou uma montanha, deseja subi-la? S/N")
    resposta = input("Escolha sua ação: ")
    if resposta == S:
        print("Voce foi subir a montanha, mas se cansou na metade e parou. Melhore este condicionamento 🤦‍♂️")
    else:
        print("Voce não tentou subir a montanha e continuou com folego.👍")